import 'package:flutter/material.dart';
bool theme = true; // true=white   false=
Color colorPageBG = theme? Colors.grey[200]:Colors.grey[700];

const Color pg = Color(0xA39A95);