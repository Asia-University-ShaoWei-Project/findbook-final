import 'package:flutter/material.dart';

class Collect extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('collect'),
      
    );
  }
}