// import 'package:flutter/material.dart';

// Widget _userScaffold(String title, Widget myBody, dynamic context) => Scaffold(
//     appBar: AppBar(
//       // backgroundColor: Colors.white,
//       // iconTheme: IconThemeData(color: Colors.black),
//       leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () => Navigator.of(context).pop()),
//       title: Center(
//         child: Text(title, style: TextStyle(color: Colors.black)),
//       ),
//     ),
//     body: myBody);

// Widget _options({String title, String intr}) => Padding(
//       padding: const EdgeInsets.symmetric(vertical: 10),
//       child: ListTile(
//         // leading: Icon(),
//         title: Text(
//           title,
//           style: TextStyle(fontSize: 20, color: Colors.black),
//         ),
//         subtitle: Text(intr),
//         trailing: Icon(
//           Icons.arrow_forward_ios,
//           size: 18,
//         ),
//         onTap: () {
//           print(title);
//           // searchNotifier.keyword = notifier.searchHistory[index]["key"];
//           // searchNotifier.notifyListeners();
//           // print("keyword : ${searchNotifier.keyword}");
//           // Navigator.of(context).pop();
//         },
//       ),
//     );
