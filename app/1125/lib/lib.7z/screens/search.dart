// --- package ---
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:provider/provider.dart';

// import 'search/search.dart';
// --- widget ---
import '../screens/search/endDrawer.dart';
import 'package:myFirst/screens/search/items/searchField.dart';
import '../screens/search/items/categoryList.dart';
import '../screens/search/items/itemList.dart';
// --- model ---
import 'package:myFirst/models/search_model.dart';



class SearchMain extends StatelessWidget {
  final controller;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  SearchMain({@required this.controller});

  @override
  Widget build(BuildContext context) {
    void _openEndDrawer() => _scaffoldKey.currentState.openEndDrawer();
    // ignore: unused_element
    void _closePage() => Navigator.of(context).pop();
    print('build Search');

    return Scaffold(
      key: _scaffoldKey,
      endDrawer: SearchEndDrawer(),
      body: Column(
        children: [
          // ----search box----
          Selector<SearchModel, dynamic>(
              selector: (context, viewModel) => viewModel,
              shouldRebuild: (pre, next) => pre != next,
              builder: (context, notifier, child)
                  // Consumer<SearchModel>(builder: (buildContext, notifier, widget)
                  =>
                  GestureDetector(
                      // onTap: () => Navigator.pushNamed(context, '/search/box'),
                      // onTap: () => Navigator.of(context).pushNamed('/search/box'),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) =>
                              SearchField(searchNotifier: notifier))),
                      child: Container(
                        margin:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                // color: Colors.grey[400].withOpacity(0.5),
                                // offset: Offset(1, 1), //X, Y
                                // blurRadius: 2,
                                // spreadRadius: 2,
                                ),
                          ],
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              splashColor: Colors.transparent,
                              onPressed: () {
                                _openEndDrawer();
                              },
                              icon: Icon(Icons.dehaze),
                            ),
                            // Text(searchNotifier.keyword, style: TextStyle(fontSize: 18),),
                            Expanded(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 15),
                                child: Text(
                                  "searhc here",
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontWeight: FontWeight.w300,
                                      fontSize: 18,
                                      letterSpacing: 1.2,
                                      color: Colors.grey[700]),
                                ),
                              ),
                            ),
                            Consumer<SearchModel>(
                              builder: (context, localNotify, child) =>
                                  IconButton(
                                splashColor: Colors.transparent,
                                onPressed: () async {
                                  localNotify
                                      .searchResult(await fetchAlbum("value"));
                                  // await fetchAlbum("value");
                                },
                                icon: Icon(Icons.mic),
                              ),
                            )
                          ],
                        ),
                      ))),
          // ---- category ----
          CategoryList(),
          // ---- item container ----
          Expanded(
            child: ItemList(controller: controller,),
          )
        ],
      ),
    );
  }
}

Future fetchAlbum(String value) async {
  var dio = Dio();

  final response = await dio
      .get(
        // "http://192.168.43.159:8000/s/test/",
        // "http://210.70.80.111/106021095/myjson.json", // school url get json
        "http://210.70.80.111/106021095/json/kingstoneMult.json",
        // queryParameters: {"id": 12, "name": "wendu"}
      )
      .timeout(const Duration(seconds: 10));
  if (response.statusCode == 200) {
    return response.data;
  } else {
    return null;
  }
}
