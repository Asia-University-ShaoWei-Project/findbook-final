import 'package:flutter/material.dart';
// import 'package:dio_cookie_manager/dio_cookie_manager.dart';
// import 'package:cookie_jar/cookie_jar.dart';
// import 'package:myFirst/Model/myModel.dart';
import 'package:provider/provider.dart';
// import 'dart:convert' show json;
// import 'user/login.dart';

import 'package:myFirst/screens/user/pages/profile.dart';
import 'package:myFirst/screens/user/pages/collect.dart';
import 'package:myFirst/screens/user/pages/settings.dart';
import 'package:myFirst/screens/user/pages/help_feedback.dart';
import 'package:myFirst/screens/user/pages/about.dart';
// ignore: must_be_immutable
import 'package:myFirst/models/user_model.dart';


class UserMain extends StatelessWidget {
  // var myNotifier;
  final List _pages = [
    Profile(),
    Collect(),
    Settings(),
    HelpFeedback(),
    About()
  ];
  final UserModel userModel = UserModel();
  final controller;
  UserMain({@required this.controller});
  @override
  Widget build(BuildContext context) {
    // final myNotifier = Provider.of<MyModel>(context, listen: false);
    return ChangeNotifierProvider(
      create: (_) => userModel,
      child: Center(
        child: ListView(
          controller: controller,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(20, 40, 20, 10),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey[300],
                    offset: Offset(0, 1), //X, Y
                    blurRadius: 0.5,
                    spreadRadius: 0.2,
                  ),
                ],
              ),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: GestureDetector(
                    onTap: () {
                      print('profile');
                    },
                    child: Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: CircleAvatar(
                            radius: 40,
                            backgroundImage:
                                AssetImage('assets/images/user.png'),
                          ),
                        ),
                        Expanded(
                          flex: 7,
                          child: ListTile(
                              title: Text("UserName",
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.black)),
                              subtitle: Text("other",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.grey[600])),
                              trailing:
                                  // CircleAvatar(
                                  //     backgroundColor: Colors.grey[700],
                                  // child:
                                  IconButton(
                                      icon: Icon(
                                        Icons.edit,
                                        size: 18,
                                        color: Colors.black,
                                      ),
                                      onPressed: () {})),
                          // ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Container(
            //   // color: Colors.teal,
            //   child: Text('other'),
            // ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Column(
                children: [
                  _optionCard(
                    [
                      _options(
                        title: "Your Notify",
                        icons: Icons.notifications,
                        color: Colors.brown[300],
                        index: 0,
                        context: context,
                      ),
                      _options(
                        title: "Your Profile",
                        icons: Icons.account_circle,
                        color: Colors.blue[700],
                        index: 1,
                        context: context,
                      ),
                      _options(
                        title: "Your Collect",
                        color: Colors.yellow[600],
                        icons: Icons.star,
                        index: 2,
                        context: context,
                      ),
                    ],
                  ),
                  _optionCard(
                    [
                      _options(
                        title: "Settings",
                        color: Colors.grey[600],
                        icons: Icons.settings,
                        index: 3,
                        context: context,
                      ),
                      _options(
                        title: "Help & Feedback",
                        color: Colors.grey,
                        icons: Icons.help_outline,
                        index: 4,
                        context: context,
                      ),
                      _options(
                        title: "About",
                        color: Colors.grey,
                        icons: Icons.info_outline,
                        index: 5,
                        context: context,
                      ),
                    ],
                  ),
                  _optionCard(
                    [
                      _options(title: "-----Test------", icons: Icons.clear),
                      _options(title: "-----Test------", icons: Icons.clear),
                      _options(title: "-----Test------", icons: Icons.clear),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _optionCard(List<Widget> options) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        child: Card(
          // color: Colors.white,
            child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(children: options))),
      );

  Widget _options(
      {String title = "",
      Color color,
      IconData icons = Icons.error,
      int index,
      dynamic context}) {
    return ListTile(
      // contentPadding: EdgeInsets.symmetric(horizontal: 5.0),
      leading: Icon(
        icons,
        color: color,
      ),
      title: Text(title),
      // subtitle: Text("20${notifier.searchHistory[index]["date"]}"),
      trailing: Icon(
        Icons.arrow_forward_ios,
        size: 18,
      ),
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => _pages[index]));
        print(title);
        // searchNotifier.keyword = notifier.searchHistory[index]["key"];
        // searchNotifier.notifyListeners();
      },
    );
  }
}
