// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';


// class Test extends StatefulWidget {
//   @override
//   _TestState createState() => _TestState();
// }

// class _TestState extends State<Test> {
//   final FirebaseFirestore firestore = FirebaseFirestore.instance;

//   CollectionReference users = FirebaseFirestore.instance.collection('User');

//   Future<void> addUser() {
//     // Call the user's CollectionReference to add a new user
//     return users
//         .add({
//           'full_name': "ray1", // John Doe
//           'company': "compan", // Stokes and Sons
//           'age': 18 // 42
//         })
//         .then((value) => print("User Added"))
//         .catchError((error) => print("Failed to add user: $error"));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container();
//   }
// }