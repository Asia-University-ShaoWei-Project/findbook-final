// --- package ---
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:scroll_bottom_navigation_bar/scroll_bottom_navigation_bar.dart';
// --- Model ---
import 'package:myFirst/models/persion_model.dart';
import 'package:myFirst/models/search_model.dart';
import 'package:myFirst/models/user_model.dart';

// import 'Pages/test.dart';
// import 'package:myFirst/Pages/future/sliding_sheet.dart';
import 'package:myFirst/screens/search/endDrawer.dart';
import 'package:myFirst/screens/search/items/searchField.dart';

// ---- srceen ----
import 'screens/loading.dart';
import 'screens/home.dart';
import 'screens/search.dart';
// import 'Pages/signIn.dart';
import 'screens/user.dart';
// import 'test.dart';
// import 'Pages/SearchWidget/tmpBox.dart';
import 'package:myFirst/screens/search/indexLoaing.dart';


void main() => runApp(
      EasyLocalization(
        supportedLocales: [
          Locale('en', 'US'),
          Locale('zh', 'CN'),
          Locale('zh', 'TW')
        ],
        path: 'assets/lang', // <-- change patch to your
        fallbackLocale: Locale('zh', 'CN'),
        child: MultiProvider(
          providers: [
            ChangeNotifierProvider(create: (_) => SelfModel()),
            ChangeNotifierProvider(create: (_) => SearchModel()),
            ChangeNotifierProvider(create: (_) => UserModel()),
          ],
          child: MaterialApp(
            // debugShowCheckedModeBanner: false,
            title: 'Find Book',
            theme: ThemeData(
              // fontFamily: 'Montserrat',
              scaffoldBackgroundColor: Colors.white,
            ),
            initialRoute: '/',
            routes: {
              '/': (context) => Loading(),
              '/index': (context) => Index(),
              '/search/box': (context) => SearchField(),
              '/search/box/drawer': (context) => SearchEndDrawer(),
            },
          ),
        ),
      ),
    );

class Index extends StatelessWidget {
  ScrollController controller = ScrollController();

  final items = <BottomNavigationBarItem>[
    // BottomNavigationBarItem(
    //   icon: Icon(Icons.home),
    //   label: "首頁", // 首頁
    // ),
    BottomNavigationBarItem(
      icon: Icon(Icons.search),
      label: "搜尋",
    ),
    BottomNavigationBarItem(icon: Icon(Icons.account_circle), label: "使用者")
  ];

  @override
  Widget build(BuildContext context) {
    print('build IndexPage');
    controller.bottomNavigationBar.height = 65;

    // booksData = booksData.isNotEmpty ? booksData : ModalRoute.of(context).settings.arguments; // 接收Loading傳來得資料
    final List pages = [
      // Test(),
      // HomeMain(controller: controller),
      // TmpBox(),
      SearchMain(controller: controller),
      // Test(),

      // UserMain(controller: controller),

      // User(controller: controller),
      Test(),
    ];
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: NotificationListener<OverscrollIndicatorNotification>(
          // ignore: missing_return
          onNotification: (overscroll) {
            overscroll.disallowGlow();
          },
          child:
              // Consumer<MyModel>(
              //   builder: (_, localNotify, __) =>
              Snap(
            controller: controller.bottomNavigationBar,
            child: ValueListenableBuilder<int>(
                valueListenable: controller.bottomNavigationBar.tabNotifier,
                builder: (context, value, child) => pages[value]), // 頁面切換
          ),
          // ),
        ),
      ),
      // ),
      bottomNavigationBar: ScrollBottomNavigationBar(
          selectedIconTheme: IconThemeData(size: 30),
          fixedColor: Colors.black, //選擇頁顏色
          backgroundColor: Colors.white,
          controller: controller,
          items: items),

      // BottomNavigationBar(
      //   items: <BottomNavigationBarItem>[
      //     BottomNavigationBarItem(icon: Icon(Icons.home), title: Text('首頁')),
      //     BottomNavigationBarItem(icon: Icon(Icons.search), title: Text('搜尋')),
      //     BottomNavigationBarItem(
      //         icon: Icon(Icons.account_circle), title: Text('用戶')),
      //     // BottomNavigationBarItem(
      //         // icon: Icon(Icons.settings), title: Text('測試')),
      //   ],

      //   elevation: 10,
      //   iconSize: 26,
      //   currentIndex: notifier.page, //目前選擇頁索引值
      //   fixedColor: Colors.black, //選擇頁顏色
      //   onTap: (index) =>notifier.barPage(index), //BottomNavigationBar 按下處理事件
      // ),
    );
  }
}

class Test extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: RaisedButton(
      onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => IndexLoading(index: 'indexNumber'))),
      child: Text('click'),
    ));
  }
}
